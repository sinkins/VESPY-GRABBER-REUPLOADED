# Extension-Spoofer
A cool python exploit to spoof your payload into another extension like pdf, docx, png, jpg, mp3, etc.

# Installation
All you need is python 3.6 and +


# Preview
![image](https://cdn.discordapp.com/attachments/938247228609409087/951614905050619964/spoofer.png)
